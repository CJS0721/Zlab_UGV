#ifndef __VCGLIB_TETRAHEDRON
#define __VCGLIB_TETRAHEDRON
#define TETRA_TYPE Tetrahedron
#include <vcg/simplex/tetrahedron/base.h> 

#endif
