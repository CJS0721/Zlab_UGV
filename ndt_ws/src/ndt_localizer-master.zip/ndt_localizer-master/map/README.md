### Map folder

put your map file here (.pcd).